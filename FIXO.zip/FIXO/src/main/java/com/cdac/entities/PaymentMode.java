package com.cdac.entities;

public enum PaymentMode {

	DEBIT_CARD, CREDIT_CARD, UPI, CASH, NET_BANKING
}
