package com.cdac.entities;

public enum PaymentStatus {
	PENDING, COMPLETED, CANCELLED, SUCCESSFUL, PROCESSING, FAILED
}
